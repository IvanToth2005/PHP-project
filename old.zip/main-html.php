
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="index.css">
<title>Project</title>
</head>
<body>
    <nav>
        <?php include 'nav-html.php'; ?>
    </nav>
    <main>
        <?php include 'index.php'; ?>
    </main>

</body>
</html>