<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Magyarország települései projectmunka</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<h1><b>Magyarország települései projectmunka</b></h1>
<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form id="countyForm" class="county-form">
                <div class="form-group">
                    <label for="countySelect">Válasszon megyét:</label>
                    <select id="countySelect" name="county" class="form-control">
                        <option value="">Válasszon megyét...</option>
                        <?php
                        // Adatbázis kapcsolat létrehozása
                        $con=mysqli_connect("localhost","root","","zip_codes");
                        if(!$con) 
                        { die("Connection Error"); }

                        // Megyék lekérdezése az adatbázisból
                        $query = "SELECT DISTINCT County FROM zip_codes";
                        $result = mysqli_query($con, $query);

                        // Mezők feldolgozása és megjelenítése a legördülő menüben
                        while($row = mysqli_fetch_assoc($result)) {
                            echo '<option value="'.$row['County'].'">'.$row['County'].'</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="cityNameFormGroup" style="display:none;">
                    <label for="cityName" id="cityNameLabel">Település neve:</label>
                    <input type="text" id="cityName" name="cityName" class="form-control">
                </div>
                <button type="button" id="addCityBtn" class="btn btn-primary" style="display:none;">Hozzáadás</button>
            </form>
            <div id="cityList"></div>
            <div id="countyImageContainer"></div> 
            <div id="alphabetButtons"></div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="index.js"></script>
<script>
    $(document).ready(function() {
        // ABC gombok létrehozása
        for (let charCode = 65; charCode <= 90; charCode++) {
            const letter = String.fromCharCode(charCode);
            $('#alphabetButtons').append('<button type="button" class="btn btn-default" onclick="filterCitiesByCounty(\'' + letter + '\')">' + letter + '</button>');
        }

        // Egyéb inicializációk és eseménykezelők...

        // Megyék kiválasztásának eseménykezelő
        $('#countySelect').change(function() {
            filterCitiesByCounty();
        });
    });

    function filterCitiesByCounty(letter) {
        const selectedCounty = $('#countySelect').val();
        // Az adatbázisból városok lekérése a kiválasztott megye és betű alapján
        const query = "SELECT City FROM zip_codes WHERE County = '" + selectedCounty + "' AND City LIKE '" + letter + "%'";
        $.ajax({
            type: "POST",
            url: "get_cities.php", // Az elérési út az adatok PHP-fájlba küldéséhez és lekéréséhez
            data: { query: query },
            success: function(response) {
                displayCities(JSON.parse(response));
            }
        });
    }

    function displayCities(cities) {
        // Városok listájának megjelenítése az ABC gombok után
        const citiesHTML = '<h4>Városok:</h4>' +
                           '<div class="btn-group" role="group" aria-label="City buttons">' +
                           cities.map(city => '<button type="button" class="btn btn-info" onclick="selectCity(\'' + city + '\')">' + city + '</button>').join('') +
                           '</div>';
        $('#cityList').html(citiesHTML);
    }

    function selectCity(city) {
        // Kiválasztott városok megjelenítése
        $('#selectedCities').append('<p>' + city + '</p>');
    }
</script>
</body>
</html>