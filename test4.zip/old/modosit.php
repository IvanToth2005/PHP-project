<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postalCode = $_POST['postalCode'];
    $newPostalCode = $_POST['newPostalCode'];
    $countyName = $_POST['countyName'];
    $newCountyName = $_POST['newCountyName'];

    // Adatbázis kapcsolat létrehozása
    try {
        $conn = new PDO("mysql:host=localhost;dbname=zip_codes", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Az adatok módosítása a Cities és Counties táblákban
        $stmt = $conn->prepare("UPDATE Cities SET postal_code = :newPostalCode WHERE postal_code = :postalCode");
        $stmt->bindParam(':postalCode', $postalCode);
        $stmt->bindParam(':newPostalCode', $newPostalCode);
        $stmt->execute();

        $stmt = $conn->prepare("UPDATE Counties SET county_name = :newCountyName WHERE county_name = :countyName");
        $stmt->bindParam(':countyName', $countyName);
        $stmt->bindParam(':newCountyName', $newCountyName);
        $stmt->execute();

        echo "Sikeres módosítás!";
    } catch(PDOException $e) {
        echo "Hiba: " . $e->getMessage();
    }
}
?>