<?php
// Adatbázis kapcsolat létrehozása
$con = mysqli_connect("localhost", "root", "", "zip_codes");
if (!$con) {
    die("Connection Error");
}

// Lekérdezés végrehajtása és válasz generálása
$query = $_POST['query'];
$result = mysqli_query($con, $query);

$zipcodes = array();
while ($row = mysqli_fetch_assoc($result)) {
    $zipcodes[] = $row['zip_code']; // Csak az irányítószámokat tartalmazó tömb
}

echo json_encode($zipcodes);
mysqli_close($con);
?>