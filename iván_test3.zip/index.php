<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Magyarország települései projectmunka</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="modosit.js"></script>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<h1><b>Magyarország települései projectmunka</b></h1>
<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form id="countyForm" class="county-form">
                <div class="form-group">
                    <label for="countySelect">Válasszon megyét:</label>
                    <select id="countySelect" name="county" class="form-control">
                        <option value="">Válasszon megyét...</option>
                        <?php
                        try {
                            $conn = new PDO("mysql:host=localhost;dbname=zip_codes", "root", "");
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            
                            $stmt = $conn->query("SELECT DISTINCT county_name FROM Counties");
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['county_name'] . '">' . $row['county_name'] . '</option>';
                            }
                        } catch(PDOException $e) {
                            echo "Hiba: " . $e->getMessage();
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group" id="cityNameFormGroup" style="display:none;">
                    <label for="cityName" id="cityNameLabel">Település neve:</label>
                    <input type="text" id="cityName" name="cityName" class="form-control">
                    <label for="cityZIP" id="cityZIPLabel">Település irányítószám:</label>
                    <input type="text" id="cityZIP" name="cityZIP" class="form-control">
                </div>
                <button type="button" id="addCityBtn" class="btn btn-primary" style="display:none;">Hozzáadás</button>
                <div>
                        
                <div class="form-group">
                <label for="searchCity">Keresés városra:</label>
                <input type="text" id="searchCity" class="form-control" placeholder="Írja be a város nevét...">
                <button type="button" id="searchCityBtn" class="btn btn-info mt-2">Keresés</button>
            </div>
            <div id="searchResult">
                <div id="postalCodeResult"></div>
                <div id="countyNameResult"></div>
                <div id="cityNameResult"></div> <!-- Új eredménytartó div a városnév megjelenítéséhez -->
            </div>
                </div>
            </form>
            <!-- ABC gombok -->
            <div id="alphabetButtons" style="text-align: center; display: none;"></div>
            <!-- Összes város kiíratása gomb -->
            <button type="button" id="allCitiesBtn" class="btn btn-success mt-2 text-center" onclick="showAllCities()">Összes város kiíratása</button>
            <!-- Megye címer -->
            <div id="countyImageContainer"></div>
            <!-- Települések listája -->
            <div id="cityList"></div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="index.js"></script>
<script>

$(document).ready(function() {
        // Kereső gomb eseménykezelő
        $('#searchCityBtn').click(function() {
            const userInput = $('#searchCity').val();
            if ($.isNumeric(userInput)) {
                // Ha a bemenet szám, akkor hívjuk meg a függvényt, amely az irányítószámhoz tartozó megyét és várost írja ki
                searchByZipCode(userInput);
            } else {
                // Ha a bemenet szöveg, akkor hívjuk meg a függvényt, amely a városnév alapján keresi az irányítószámot és a megyét
                searchByCityName(userInput);
            }
        });
    });

    function searchByZipCode(zipCode) {
        $.ajax({
            type: "POST",
            url: "get_city_and_county_by_zipcode.php",
            data: { zipCode: zipCode },
            success: function(response) {
                const data = JSON.parse(response);
                $('#postalCodeResult').html('<p>Irányítószám: ' + zipCode + '</p>');
                $('#countyNameResult').html('<p>Megye: ' + data.countyName + '</p>');
                $('#cityNameResult').html('<p>Város: ' + data.cityName + '</p>');
            }
        });
    }

    function searchByCityName(cityName) {
        $.ajax({
            type: "POST",
            url: "get_postal_code.php",
            data: { cityName: cityName },
            success: function(response) {
                const postalCode = JSON.parse(response).postalCode;
                $('#postalCodeResult').html('<p>Irányítószám: ' + postalCode + '</p>');
                $.ajax({
                    type: "POST",
                    url: "get_county_name.php",
                    data: { cityName: cityName },
                    success: function(response) {
                        const countyName = JSON.parse(response).countyName;
                        $('#countyNameResult').html('<p>Megye: ' + countyName + '</p>');
                    }
                });
            }
        });
    }

    function showAllCities() {
        const selectedCounty = $('#countySelect').val();

        // Ellenőrizzük, hogy van-e kiválasztott megye
        if (selectedCounty) {
            // Az adatbázisból városok lekérése az adott megyében
            const query = "SELECT city_name FROM Cities WHERE county_id IN (SELECT county_id FROM Counties WHERE county_name = '" + selectedCounty + "')";
            $.ajax({
                type: "POST",
                url: "get_cities.php",
                data: { query: query },
                success: function(response) {
                    const allCities = JSON.parse(response);
                    displayCities(allCities);
                }
            });
        }
    }

    $(document).ready(function() {
        // ABC gombok létrehozása
        for (let charCode = 65; charCode <= 90; charCode++) {
            const letter = String.fromCharCode(charCode);
            $('#alphabetButtons').append('<button type="button" class="btn btn-default" onclick="filterCitiesByCounty(\'' + letter + '\')">' + letter + '</button>');
        }

        // Egyéb inicializációk és eseménykezelők...

        // Megyék kiválasztásának eseménykezelő
        $('#countySelect').change(function() {
            // Ha van kiválasztott megye, megjelenítjük az ABC gombokat és a hozzáadás gombot
            if ($(this).val()) {
                $('#alphabetButtons, #addCityBtn').show();
            } else {
                // Ha nincs kiválasztott megye, elrejtjük az ABC gombokat és a hozzáadás gombot
                $('#alphabetButtons, #addCityBtn').hide();
            }
            filterCitiesByCounty();
        });
    });

    function filterCitiesByCounty(letter) {
    const selectedCounty = $('#countySelect').val();
    // Az adatbázisból városok lekérése a kiválasztott megye és betű alapján
    const query = "SELECT city_name FROM Cities WHERE county_id IN (SELECT county_id FROM Counties WHERE county_name = '" + selectedCounty + "') AND city_name LIKE '" + letter + "%'";
    $.ajax({
        type: "POST",
        url: "get_cities.php", // Az elérési út az adatok PHP-fájlba küldéséhez és lekéréséhez
        data: { query: query },
        success: function(response) {
            displayCities(JSON.parse(response), true); // Új paraméter a városok kiírásának módjához
        }
    });
}

function displayCities(cities, isFiltered) {
    const citiesHTML = '<h4>Városok:</h4>' +
        '<div class="city-list">' +
        cities.map(city => '<div class="city">' +
            '<div class="container">' + city.zip_code + ' - ' + city.city_name + '</div>' +
            '<div class="delete-container">' +
            '<button class="btn btn-danger deleteBtn" data-city="' + city.city_name + '">Törlés</button>' +
            '</div>' +
            '</div>').join('') +
        '</div>';
    $('#cityList').html(citiesHTML);

    // Törlés gombok eseménykezelőjének hozzáadása (új városoknál és a szűrt városoknál)
    $('.deleteBtn').off('click').on('click', function (e) {
        e.preventDefault(); // Az alapértelmezett művelet megakadályozása
        var cityName = $(this).data('city'); // Település nevének kinyerése

        // Törlési művelet végrehajtása a cityName alapján
        $.ajax({
            url: 'eltavolit.php',
            method: 'POST',
            data: {cityName: cityName},
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    // Település sikeresen eltávolítva
                    console.log('Település sikeresen eltávolítva: ' + cityName);
                    // Újra betöltjük a településeket
                    $('#countySelect').trigger('change');
                } else {
                    // Hiba történt a törlés során
                    console.error('Hiba történt a település törlésekor: ' + response.message);
                }
            },
            error: function (xhr, status, error) {
                // Hibakezelés AJAX hiba esetén
                console.error('AJAX hiba:', status, error);
            }
        });
    });
}

    function selectCity(city) {
    // Kiválasztott városok megjelenítése
    $('#selectedCities').append('<p>' + city + '</p>');
}

</script>
<?php
// Adatbázis kapcsolódás
try {
    $conn = new PDO("mysql:host=localhost;dbname=zip_codes", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
    // Adatok lekérése és exportálása CSV fájlba
    $file = fopen("exported_data.csv", 'w'); // A CSV fájl megnyitása
 
    // Fejléc létrehozása
    fputcsv($file, array('county_name', 'zip_code', 'city_name'));
 
    // Adatok lekérése és írása a CSV fájlba
    $query = "SELECT Counties.county_name, ZipCodes.zip_code, Cities.city_name
              FROM Counties
              INNER JOIN Cities ON Cities.county_id = Counties.county_id
              INNER JOIN ZipCodes ON ZipCodes.zip_code_id = Cities.zip_code_id";
    $result = $conn->query($query);
 
    if ($result->rowCount() > 0) {
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($file, $row); // Sor írása a CSV fájlba
        }
    } else {
        echo "Nincs adat az adatbázisban.";
    }
 
    // CSV fájl bezárása
    fclose($file);
 
    // Adatbázis kapcsolat bezárása
    $conn = null;
} catch(PDOException $e) {
    echo "Hiba: " . $e->getMessage();
}
?>
</body>
</html>
