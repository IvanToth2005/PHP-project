// Új gomb hozzáadása a városokhoz módosítás funkcióval
function addModifyCityButton(city) {
    $('#cityList').append('<button type="button" class="btn btn-warning" onclick="modifyCity(\'' + city + '\')">Módosítás</button>');
}

// Módosítás funkció
function modifyCity(city) {
    // TODO: Implementálni kell a város módosítását (megye és irányítószám) az adatbázisban
    const newCounty = prompt('Adja meg az új megyét:');
    const newPostalCode = prompt('Adja meg az új irányítószámot:');

    if (newCounty !== null && newPostalCode !== null) {
        $.ajax({
            type: "POST",
            url: "modify_city.php",
            data: { city: city, county: newCounty, postalCode: newPostalCode },
            success: function(response) {
                alert(response); // Válasz kezelése
                // Frissítjük a városokat
                filterCitiesByCounty();
            }
        });
    }
}