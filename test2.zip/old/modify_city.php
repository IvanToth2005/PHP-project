<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Adatbázis kapcsolódás
    $conn = new PDO("mysql:host=localhost;dbname=zip_codes", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Város, megye és irányítószám lekérése
    $city = $_POST["city"];
    $newCounty = $_POST["county"];
    $newPostalCode = $_POST["postalCode"];

    // Város módosítása
    $stmt = $conn->prepare("UPDATE Cities SET county_id = (SELECT county_id FROM Counties WHERE county_name = :newCounty), postal_code = :newPostalCode WHERE city_name = :city");
    $stmt->bindParam(':newCounty', $newCounty, PDO::PARAM_STR);
    $stmt->bindParam(':newPostalCode', $newPostalCode, PDO::PARAM_STR);
    $stmt->bindParam(':city', $city, PDO::PARAM_STR);
    $stmt->execute();

    echo "A város módosítva lett!";
}
?>